﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* 
 * Name: Sushmita Nandalan
 * Date: August 4, 2017
 * Student ID: 300923159
 * Description: BMI Calculator project
 * Version: 0.1 - Created the Project
 */

namespace COMP123_S2017_Assignment5
{
	public partial class BMI_Calculator : Form
	{
		public BMI_Calculator()
		{
			InitializeComponent();
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void tableLayout_Paint(object sender, PaintEventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{

		}

		private void label1_Click(object sender, EventArgs e)
		{

		}
	}
}
